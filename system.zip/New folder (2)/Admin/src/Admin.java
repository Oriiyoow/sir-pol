
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.ui.HorizontalAlignment;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class Admin extends javax.swing.JFrame {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/integrative_final";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    private Connection connectToDatabase() {
        try {
            return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage());
            return null;
        }
    }

    private void createBarChart(String selectedMonth) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try (Connection conn = connectToDatabase()) {
            if (selectedMonth.equals("This Year")) {
                // Query to get the total quantity for each month of the current year
                String query = "SELECT MONTH(r.reserved_at) AS month, SUM(r.reserved_quantity) AS total_quantity "
                        + "FROM reservations r "
                        + "WHERE YEAR(r.reserved_at) = YEAR(CURRENT_DATE) "
                        + "GROUP BY MONTH(r.reserved_at)";
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();

                // Populate dataset for each month
                while (rs.next()) {
                    int month = rs.getInt("month");
                    int quantity = rs.getInt("total_quantity");
                    dataset.addValue(quantity, "Quantity", getMonthName(month));
                }
            } else {
                int month = getMonthNumber(selectedMonth); // Convert month name to number

                // Query for a specific month
                String query = "SELECT i.name, SUM(r.reserved_quantity) AS total_quantity "
                        + "FROM inventory i "
                        + "JOIN reservations r ON i.item_id = r.item_id "
                        + "WHERE MONTH(r.reserved_at) = ? "
                        + "GROUP BY i.name";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, month);
                ResultSet rs = stmt.executeQuery();

                // Populate dataset for the selected month
                while (rs.next()) {
                    String itemName = rs.getString("name");
                    int quantity = rs.getInt("total_quantity");
                    dataset.addValue(quantity, "Quantity", itemName);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to load chart data: " + e.getMessage());
            return;
        }

        // Create the bar chart
        JFreeChart barChart = ChartFactory.createBarChart(
                "Product Purchases for " + selectedMonth, // Chart title
                "Product", // Domain axis label
                "Quantity", // Range axis label
                dataset // Data
        );

        // Customize the chart design
        CategoryPlot plot = barChart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setBarPainter(new StandardBarPainter());
        renderer.setSeriesPaint(0, Color.BLUE); // Set bar color

        // Set the chart title with dynamic text
        TextTitle title = new TextTitle("Product Purchases for " + selectedMonth, new Font("Arial", Font.BOLD, 18));
        title.setHorizontalAlignment(HorizontalAlignment.CENTER);
        barChart.setTitle(title);

        // Clear the previous chart and add the new chart
        chart_panel.removeAll();
        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new Dimension(640, 330));
        chart_panel.add(chartPanel);
        chart_panel.revalidate();
        chart_panel.repaint();
    }

    private String getMonthName(int month) {
        switch (month) {
            case 1:
                return "January";
            case 2:
                return "February";
            case 3:
                return "March";
            case 4:
                return "April";
            case 5:
                return "May";
            case 6:
                return "June";
            case 7:
                return "July";
            case 8:
                return "August";
            case 9:
                return "September";
            case 10:
                return "October";
            case 11:
                return "November";
            case 12:
                return "December";
            default:
                return "";
        }
    }

    private int getMonthNumber(String monthName) {
        switch (monthName) {
            case "January":
                return 1;
            case "February":
                return 2;
            case "March":
                return 3;
            case "April":
                return 4;
            case "May":
                return 5;
            case "June":
                return 6;
            case "July":
                return 7;
            case "August":
                return 8;
            case "September":
                return 9;
            case "October":
                return 10;
            case "November":
                return 11;
            case "December":
                return 12;
            case "This Year":
                return 0; // Special case for this year
            default:
                return 0; // Default case
        }
    }

    private void loadInventoryTable() {
        try (Connection conn = connectToDatabase()) {
            String query = "SELECT * FROM inventory";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            DefaultTableModel model = (DefaultTableModel) inventory_table.getModel();
            model.setRowCount(0); // Clear existing rows

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("item_id"),
                    rs.getString("name"),
                    rs.getString("sku"),
                    rs.getString("description"),
                    rs.getInt("quantity"),
                    rs.getTimestamp("created_at"),
                    rs.getTimestamp("updated_at"),
                    rs.getString("added_by_username"),
                    rs.getDouble("amount"),});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to load inventory: " + e.getMessage());
        }
    }

    private void loadUserTable() {
        try (Connection conn = connectToDatabase()) {
            String query = "SELECT * FROM users";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            DefaultTableModel model = (DefaultTableModel) user_table.getModel();
            model.setRowCount(0); // Clear existing rows

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("user_id"),
                    rs.getString("username"),
                    rs.getString("email"),
                    rs.getString("role"),
                    rs.getTimestamp("created_at")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to load users: " + e.getMessage());
        }
    }

    private void updateLabels() {
        try (Connection conn = connectToDatabase()) {
            // Query to get total items
            String totalItemsQuery = "SELECT COUNT(*) AS total_items FROM inventory";
            Statement stmt1 = conn.createStatement();
            ResultSet rs1 = stmt1.executeQuery(totalItemsQuery);
            if (rs1.next()) {
                total_items.setText("" + rs1.getInt("total_items"));
                total_items.revalidate();
                total_items.repaint();
            }

            // Query to get reserved items
            String reservedItemsQuery = "SELECT COUNT(DISTINCT reservation_id) AS reserved_items FROM reservations";
            Statement stmt2 = conn.createStatement();
            ResultSet rs2 = stmt2.executeQuery(reservedItemsQuery);
            if (rs2.next()) {
                reserved_items.setText("" + rs2.getInt("reserved_items"));
                reserved_items.revalidate();
                reserved_items.repaint();
            }

            // Query to get pending approvals
            String pendingApprovalsQuery = "SELECT COUNT(*) AS status FROM reservations WHERE status = 'Pending'";
            Statement stmt3 = conn.createStatement();
            ResultSet rs3 = stmt3.executeQuery(pendingApprovalsQuery);
            if (rs3.next()) {
                pending_approvals.setText("" + rs3.getInt("status"));
                pending_approvals.revalidate();
                pending_approvals.repaint();
            }

            // Query to get total users
            String totalUsersQuery = "SELECT COUNT(*) AS total_users FROM users";
            Statement stmt4 = conn.createStatement();
            ResultSet rs4 = stmt4.executeQuery(totalUsersQuery);
            if (rs4.next()) {
                int userCount = rs4.getInt("total_users");
                System.out.println("Total Users: " + userCount);
                total_user.setText("" + userCount);
                total_user.revalidate();
                total_user.repaint();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to update labels: " + e.getMessage());
        }
    }

    private void loadMY_RESERVATION_TABLE() {
        try (Connection conn = connectToDatabase()) {
            String query = "SELECT reservation_id, item_id, user_id, reserved_quantity, down_payment, status, reserved_at, updated_at, reserved_by_username FROM reservations";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            DefaultTableModel model = (DefaultTableModel) reserved_table.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("reservation_id"),
                    rs.getInt("item_id"),
                    rs.getInt("user_id"),
                    rs.getInt("reserved_quantity"),
                    rs.getDouble("down_payment"),
                    rs.getString("status"),
                    rs.getTimestamp("reserved_at"),
                    rs.getTimestamp("updated_at"), // Corrected this line
                    rs.getString("reserved_by_username"),});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to load reservation: " + e.getMessage());
        }
    }

    /**
     * Creates new form Admin
     */
    public Admin() {
        initComponents();
        updateLabels();
        jTabbedPane1.setSelectedIndex(0);
        loadMY_RESERVATION_TABLE();
        loadUserTable();
        String selectedMonth = (String) monthly_top_product_combo_box.getSelectedItem();
        createBarChart(selectedMonth); // Pass the selected month to the chart method
        customizeTables(); // Call the customization method
        updateStockWarnings();
    }

    private void customizeTables() {
        customizeTable(inventory_table);
        customizeTable(user_table);
        customizeTable(reserved_table);
    }

    private void customizeTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14)); // Set font style
        table.setRowHeight(30); // Set row height
        table.getTableHeader().setBackground(new Color(128, 0, 0)); // Header background color
        table.getTableHeader().setForeground(Color.RED); // Header text color
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14)); // Header font style

        // Set alternating row colors
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row) {
                Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row);
                if (row % 2 == 0) {
                    cell.setBackground(new Color(240, 240, 240)); // Light gray for even rows
                } else {
                    cell.setBackground(Color.WHITE); // White for odd rows
                }
                if (isSelected) {
                    cell.setBackground(new Color(255, 165, 0)); // Orange for selected row
                    cell.setForeground(Color.WHITE);
                } else {
                    cell.setForeground(Color.BLACK);
                }
                return cell;
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        reservation_btn = new javax.swing.JButton();
        inventory_btn = new javax.swing.JButton();
        dashboard_btn = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        user_btn1 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        total_user = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        pending_approvals = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        reserved_items = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        total_items = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        Inventory_Tab = new javax.swing.JTabbedPane();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        inventory_table = new javax.swing.JTable();
        search_inventory_input_field = new javax.swing.JTextField();
        edit_invent = new javax.swing.JButton();
        delete_invent = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        user_tab = new javax.swing.JTabbedPane();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        user_table = new javax.swing.JTable();
        change_role_btn = new javax.swing.JButton();
        search_user_input_field = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        reserved_table = new javax.swing.JTable();
        jPanel19 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        search_reservation_input_field = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        report_button = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        chart_panel = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        export_report_btn = new javax.swing.JButton();
        panel_for_stocks_warnings_etc = new javax.swing.JPanel();
        monthly_top_product_combo_box = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(128, 0, 0));
        jPanel1.setLayout(null);

        reservation_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        reservation_btn.setText("RESERVATION");
        reservation_btn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        reservation_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reservation_btnActionPerformed(evt);
            }
        });
        jPanel1.add(reservation_btn);
        reservation_btn.setBounds(30, 320, 220, 44);

        inventory_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        inventory_btn.setText("INVENTORY MANAGEMENT");
        inventory_btn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inventory_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inventory_btnActionPerformed(evt);
            }
        });
        jPanel1.add(inventory_btn);
        inventory_btn.setBounds(30, 200, 220, 44);

        dashboard_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        dashboard_btn.setText("DASHBOARD");
        dashboard_btn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        dashboard_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashboard_btnActionPerformed(evt);
            }
        });
        jPanel1.add(dashboard_btn);
        dashboard_btn.setBounds(30, 140, 220, 44);

        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setText("SUMMARY");
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4);
        jButton4.setBounds(30, 380, 220, 44);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 215, 0));
        jLabel6.setText("ADMIN");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(100, 70, 80, 60);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 215, 0));
        jLabel7.setText("EVSU-RESERVE");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(50, 30, 180, 60);

        user_btn1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        user_btn1.setText("USER MANAGEMENT");
        user_btn1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        user_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_btn1ActionPerformed(evt);
            }
        });
        jPanel1.add(user_btn1);
        user_btn1.setBounds(30, 260, 220, 44);

        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setText("EXIT");
        jButton5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5);
        jButton5.setBounds(30, 700, 220, 44);

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 770));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel8.setBackground(new java.awt.Color(153, 0, 0));
        jPanel8.setLayout(null);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 30)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("DASHBOARD OVERVIEW");
        jPanel8.add(jLabel5);
        jLabel5.setBounds(40, 20, 440, 40);

        jPanel4.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 960, 80));

        jPanel10.setBackground(new java.awt.Color(255, 215, 0));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-users-50.png"))); // NOI18N
        jLabel1.setText("Total Users");
        jPanel10.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, 150, 50));

        total_user.setFont(new java.awt.Font("Segoe UI", 1, 60)); // NOI18N
        total_user.setText("0");
        jPanel10.add(total_user, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, -1, 60));

        jPanel4.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 450, 430, 290));

        jPanel14.setBackground(new java.awt.Color(255, 215, 0));
        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-pending-50.png"))); // NOI18N
        jLabel3.setText("Pending Approvals");
        jPanel14.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 200, 50));

        pending_approvals.setFont(new java.awt.Font("Segoe UI", 1, 60)); // NOI18N
        pending_approvals.setText("0");
        jPanel14.add(pending_approvals, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 120, -1, 60));

        jPanel4.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 450, 440, 290));

        jPanel15.setBackground(new java.awt.Color(255, 215, 0));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-reserve-50.png"))); // NOI18N
        jLabel2.setText("Reserved Items");
        jPanel15.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 150, 50));

        reserved_items.setFont(new java.awt.Font("Segoe UI", 1, 60)); // NOI18N
        reserved_items.setText("0");
        jPanel15.add(reserved_items, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 120, -1, 60));

        jPanel4.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 130, 440, 290));

        jPanel16.setBackground(new java.awt.Color(255, 215, 0));
        jPanel16.setForeground(new java.awt.Color(255, 215, 0));
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setBackground(new java.awt.Color(255, 215, 0));
        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-item-50.png"))); // NOI18N
        jLabel4.setText("Total Items");
        jPanel16.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 150, 50));

        total_items.setFont(new java.awt.Font("Segoe UI", 1, 60)); // NOI18N
        total_items.setText("0");
        jPanel16.add(total_items, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, -1, 60));

        jPanel4.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 130, 430, 290));

        jTabbedPane1.addTab("tab3", jPanel4);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(null);

        Inventory_Tab.setBackground(new java.awt.Color(255, 215, 0));
        Inventory_Tab.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        Inventory_Tab.setForeground(new java.awt.Color(128, 0, 0));

        jPanel11.setBackground(new java.awt.Color(128, 0, 0));
        jPanel11.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel11.setLayout(null);

        inventory_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Item_id", "Name", "Sku", "Description", "Quantity", "Created_at", "Updated_at", "Added_by", "Amount"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(inventory_table);

        jPanel11.add(jScrollPane1);
        jScrollPane1.setBounds(10, 92, 940, 440);

        search_inventory_input_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_inventory_input_fieldActionPerformed(evt);
            }
        });
        jPanel11.add(search_inventory_input_field);
        search_inventory_input_field.setBounds(90, 40, 330, 40);

        edit_invent.setBackground(new java.awt.Color(255, 215, 0));
        edit_invent.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        edit_invent.setForeground(new java.awt.Color(128, 0, 0));
        edit_invent.setText("EDIT");
        edit_invent.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        edit_invent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_inventActionPerformed(evt);
            }
        });
        jPanel11.add(edit_invent);
        edit_invent.setBounds(10, 550, 160, 40);

        delete_invent.setBackground(new java.awt.Color(255, 215, 0));
        delete_invent.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        delete_invent.setForeground(new java.awt.Color(128, 0, 0));
        delete_invent.setText("DELETE");
        delete_invent.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        delete_invent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_inventActionPerformed(evt);
            }
        });
        jPanel11.add(delete_invent);
        delete_invent.setBounds(770, 550, 180, 40);

        jLabel15.setBackground(new java.awt.Color(255, 215, 0));
        jLabel15.setFont(new java.awt.Font("Segoe UI Historic", 3, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 215, 0));
        jLabel15.setText("SEARCH: ");
        jPanel11.add(jLabel15);
        jLabel15.setBounds(20, 50, 80, 20);

        Inventory_Tab.addTab("Manage Items", jPanel11);

        jPanel3.add(Inventory_Tab);
        Inventory_Tab.setBounds(60, 120, 970, 650);

        jPanel12.setBackground(new java.awt.Color(153, 0, 0));
        jPanel12.setLayout(null);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 30)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("INVENTORY MANAGMENT");
        jPanel12.add(jLabel8);
        jLabel8.setBounds(40, 20, 440, 40);

        jPanel3.add(jPanel12);
        jPanel12.setBounds(60, 30, 970, 80);

        jTabbedPane1.addTab("tab2", jPanel3);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        jPanel18.setBackground(new java.awt.Color(153, 0, 0));
        jPanel18.setLayout(null);

        jLabel18.setFont(new java.awt.Font("Times New Roman", 1, 30)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("USER MANAGMENT");
        jPanel18.add(jLabel18);
        jLabel18.setBounds(40, 20, 440, 40);

        jPanel2.add(jPanel18);
        jPanel18.setBounds(60, 30, 970, 80);

        user_tab.setBackground(new java.awt.Color(255, 215, 0));
        user_tab.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        user_tab.setForeground(new java.awt.Color(128, 0, 0));

        jPanel13.setBackground(new java.awt.Color(128, 0, 0));
        jPanel13.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel13.setLayout(null);

        user_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Username", "Email", "Role", "Action"
            }
        ));
        jScrollPane2.setViewportView(user_table);

        jPanel13.add(jScrollPane2);
        jScrollPane2.setBounds(10, 92, 940, 490);

        change_role_btn.setBackground(new java.awt.Color(255, 215, 0));
        change_role_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        change_role_btn.setForeground(new java.awt.Color(128, 0, 0));
        change_role_btn.setText("Change Role");
        change_role_btn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        change_role_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                change_role_btnActionPerformed(evt);
            }
        });
        jPanel13.add(change_role_btn);
        change_role_btn.setBounds(780, 30, 170, 40);

        search_user_input_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_user_input_fieldActionPerformed(evt);
            }
        });
        jPanel13.add(search_user_input_field);
        search_user_input_field.setBounds(90, 30, 330, 40);

        jLabel16.setBackground(new java.awt.Color(255, 215, 0));
        jLabel16.setFont(new java.awt.Font("Segoe UI Historic", 3, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 215, 0));
        jLabel16.setText("SEARCH: ");
        jPanel13.add(jLabel16);
        jLabel16.setBounds(10, 40, 80, 20);

        user_tab.addTab("Manage User", jPanel13);

        jPanel2.add(user_tab);
        user_tab.setBounds(60, 120, 970, 640);

        jTabbedPane1.addTab("tab1", jPanel2);

        jPanel5.setLayout(null);

        reserved_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Reservation_id", " item id", "user id", "Quantity", "Reservation Amount", "Status", "Reserved Date", "Updated At", "Reserved by"
            }
        ));
        jScrollPane3.setViewportView(reserved_table);

        jPanel5.add(jScrollPane3);
        jScrollPane3.setBounds(80, 182, 940, 510);

        jPanel19.setBackground(new java.awt.Color(153, 0, 0));
        jPanel19.setLayout(null);

        jLabel19.setFont(new java.awt.Font("Times New Roman", 1, 30)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("RESERVATION MANAGMENT");
        jPanel19.add(jLabel19);
        jLabel19.setBounds(60, 20, 440, 40);

        jPanel5.add(jPanel19);
        jPanel19.setBounds(70, 30, 960, 80);

        search_reservation_input_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        search_reservation_input_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_reservation_input_fieldActionPerformed(evt);
            }
        });
        jPanel5.add(search_reservation_input_field);
        search_reservation_input_field.setBounds(180, 130, 200, 40);

        jLabel17.setBackground(new java.awt.Color(255, 215, 0));
        jLabel17.setFont(new java.awt.Font("Segoe UI Historic", 3, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 215, 0));
        jLabel17.setText("SEARCH: ");
        jPanel5.add(jLabel17);
        jLabel17.setBounds(100, 140, 80, 20);

        jPanel17.setBackground(new java.awt.Color(153, 0, 0));
        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        report_button.setBackground(new java.awt.Color(128, 0, 0));
        report_button.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        report_button.setForeground(new java.awt.Color(255, 255, 255));
        report_button.setText("REPORT");
        report_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                report_buttonActionPerformed(evt);
            }
        });
        jPanel17.add(report_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 590, 160, 40));

        jPanel5.add(jPanel17);
        jPanel17.setBounds(70, 120, 960, 650);
        jPanel5.add(jPanel7);
        jPanel7.setBounds(610, 110, 10, 10);

        jTabbedPane1.addTab("tab4", jPanel5);

        jPanel6.setLayout(null);

        jPanel20.setBackground(new java.awt.Color(153, 0, 0));
        jPanel20.setLayout(null);

        jLabel20.setFont(new java.awt.Font("Times New Roman", 1, 30)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Summary");
        jPanel20.add(jLabel20);
        jLabel20.setBounds(60, 20, 440, 40);

        jPanel6.add(jPanel20);
        jPanel20.setBounds(70, 30, 960, 80);

        jPanel21.setBackground(new java.awt.Color(153, 0, 0));
        jPanel21.setLayout(null);

        chart_panel.setBackground(new java.awt.Color(255, 204, 204));
        jPanel21.add(chart_panel);
        chart_panel.setBounds(270, 70, 640, 330);

        jLabel12.setFont(new java.awt.Font("Segoe UI Historic", 3, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Month");
        jPanel21.add(jLabel12);
        jLabel12.setBounds(50, 70, 70, 20);

        export_report_btn.setBackground(new java.awt.Color(255, 215, 0));
        export_report_btn.setFont(new java.awt.Font("Segoe UI Historic", 3, 14)); // NOI18N
        export_report_btn.setText("Export");
        export_report_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                export_report_btnActionPerformed(evt);
            }
        });
        jPanel21.add(export_report_btn);
        export_report_btn.setBounds(780, 590, 130, 40);

        panel_for_stocks_warnings_etc.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel21.add(panel_for_stocks_warnings_etc);
        panel_for_stocks_warnings_etc.setBounds(50, 420, 860, 160);

        monthly_top_product_combo_box.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "This Year", "January", "February", "March", "April", "May ", "June", "July ", "August", "September", "October", "November", "December" }));
        monthly_top_product_combo_box.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monthly_top_product_combo_boxActionPerformed(evt);
            }
        });
        jPanel21.add(monthly_top_product_combo_box);
        monthly_top_product_combo_box.setBounds(50, 90, 190, 40);

        jLabel13.setFont(new java.awt.Font("Segoe UI Historic", 3, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Monthly Top Product Purchases");
        jPanel21.add(jLabel13);
        jLabel13.setBounds(440, 30, 380, 32);

        jPanel6.add(jPanel21);
        jPanel21.setBounds(70, 120, 960, 650);

        jTabbedPane1.addTab("tab5", jPanel6);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(217, -40, 1050, 810));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void reservation_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reservation_btnActionPerformed
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_reservation_btnActionPerformed

    private void inventory_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inventory_btnActionPerformed
        jTabbedPane1.setSelectedIndex(1);
        loadInventoryTable();
        updateLabels();
    }//GEN-LAST:event_inventory_btnActionPerformed

    private void dashboard_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashboard_btnActionPerformed
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_dashboard_btnActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void search_user_input_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_user_input_fieldActionPerformed
        try (Connection conn = connectToDatabase()) {
            String keyword = search_user_input_field.getText().trim();
            String query = "SELECT * FROM users WHERE username LIKE ? OR email LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, "%" + keyword + "%");
            stmt.setString(2, "%" + keyword + "%");

            ResultSet rs = stmt.executeQuery();
            DefaultTableModel model = (DefaultTableModel) user_table.getModel();
            model.setRowCount(0); // Clear existing rows

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("user_id"),
                    rs.getString("username"),
                    rs.getString("email"),
                    rs.getString("role"),
                    rs.getTimestamp("created_at")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to search users: " + e.getMessage());
        }
    }//GEN-LAST:event_search_user_input_fieldActionPerformed

    private void change_role_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_change_role_btnActionPerformed
        int selectedRow = user_table.getSelectedRow();  // Get the index of the selected row

        if (selectedRow != -1) {  // If a row is selected
            // Get the user_id from the selected row
            int userId = (int) user_table.getValueAt(selectedRow, 0); // Assuming user_id is in the first column
            String currentRole = user_table.getValueAt(selectedRow, 3).toString(); // Assuming role is in the fourth column

            // Prompt the admin to choose a new role
            String newRole = JOptionPane.showInputDialog(this, "Change role for user ID " + userId + " (current role: " + currentRole + "):\nEnter 'Student' or 'Staff':");

            // Validate input
            if (newRole != null && (newRole.equalsIgnoreCase("Student") || newRole.equalsIgnoreCase("Staff"))) {
                try (Connection conn = connectToDatabase()) {
                    String query = "UPDATE users SET role = ? WHERE user_id = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setString(1, newRole);
                    stmt.setInt(2, userId);

                    int rowsUpdated = stmt.executeUpdate();
                    if (rowsUpdated > 0) {
                        JOptionPane.showMessageDialog(this, "User role updated successfully!");
                        loadUserTable(); // Refresh the user table
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to update user role.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid role. Please enter 'Student' or 'Staff'.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a user to change the role.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_change_role_btnActionPerformed

    private void user_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_btn1ActionPerformed
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_user_btn1ActionPerformed

    private void search_reservation_input_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_reservation_input_fieldActionPerformed
        try (Connection conn = connectToDatabase()) {
            String keyword = search_reservation_input_field.getText().trim();
            String query = "SELECT * FROM reservations WHERE reservation_id LIKE ? OR user_id LIKE ? OR status LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            String searchPattern = "%" + keyword + "%";
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            stmt.setString(3, searchPattern);

            ResultSet rs = stmt.executeQuery();
            DefaultTableModel model = (DefaultTableModel) reserved_table.getModel();
            model.setRowCount(0); // Clear existing rows

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("reservation_id"),
                    rs.getInt("item_id"),
                    rs.getInt("user_id"),
                    rs.getInt("reserved_quantity"),
                    rs.getDouble("down_payment"),
                    rs.getString("status"),
                    rs.getTimestamp("reserved_at"),
                    rs.getTimestamp("updated_at"),
                    rs.getString("reserved_by_username"),});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to search reservations: " + e.getMessage());
        }
    }//GEN-LAST:event_search_reservation_input_fieldActionPerformed

    private void report_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_report_buttonActionPerformed
        try (Connection conn = connectToDatabase()) {
            String query = "SELECT * FROM reservations"; // Modify as needed for filtering
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            StringBuilder reportBuilder = new StringBuilder();
            reportBuilder.append("Reservation Report\n");
            reportBuilder.append("Date: ").append(new SimpleDateFormat("yyyy-MM-dd").format(new Date())).append("\n\n");

            // Column Headings
            reportBuilder.append(String.format("%-15s %-10s %-10s %-15s %-15s %-10s %-20s\n",
                    "Reservation ID", "Item ID", "User ID", "Quantity", "Down Payment", "Status", "Reserved By"));
            reportBuilder.append("-------------------------------------------------------------------------------------------\n");

            while (rs.next()) {
                reportBuilder.append(String.format("%-15d %-10d %-10d %-15d %-15.2f %-10s %-20s\n",
                        rs.getInt("reservation_id"),
                        rs.getInt("item_id"),
                        rs.getInt("user_id"),
                        rs.getInt("reserved_quantity"),
                        rs.getDouble("down_payment"),
                        rs.getString("status"),
                        rs.getString("reserved_by_username")));
            }

            // Create a JTextArea and format display
            JTextArea textArea = new JTextArea(reportBuilder.toString());
            textArea.setEditable(false);
            textArea.setFont(new Font("Monospaced", Font.PLAIN, 12)); // Use monospaced font for alignment
            textArea.setBackground(Color.WHITE);
            textArea.setForeground(Color.BLACK);

            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(800, 300)); // Set a preferred size for visibility

            // Display report in a dialog
            JOptionPane.showMessageDialog(this, scrollPane, "Reservation Report", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Report generation failed: " + e.getMessage());
        }
    }//GEN-LAST:event_report_buttonActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void delete_inventActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_inventActionPerformed
        int selectedRow = inventory_table.getSelectedRow();  // Get selected row index

        if (selectedRow != -1) {  // Check if a row is selected
            int itemId = (int) inventory_table.getValueAt(selectedRow, 0);  // Get item_id from the selected row

            try (Connection conn = connectToDatabase()) {
                String query = "DELETE FROM inventory WHERE item_id = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, itemId);  // Set item_id in the query

                int rowsDeleted = stmt.executeUpdate();  // Execute the query
                if (rowsDeleted > 0) {
                    // Remove the row from the table
                    DefaultTableModel model = (DefaultTableModel) inventory_table.getModel();
                    model.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(this, "Item deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to delete item from the database.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_delete_inventActionPerformed

    private void updateStockWarnings() {
        String warnings = "Stock Warnings:\n";
        // Fetch stock warnings from your database or business logic
        try (Connection conn = connectToDatabase()) {
            String query = "SELECT name, quantity FROM inventory WHERE quantity < 10"; // Adjust based on your schema
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                String item = rs.getString("name");
                int quantity = rs.getInt("quantity");
                warnings += String.format("Item: %s, Quantity: %d\n", item, quantity);
            }
        } catch (Exception e) {
            warnings += "Failed to load stock warnings: " + e.getMessage();
        }

        JTextArea warningArea = new JTextArea(warnings);
        warningArea.setEditable(false);
        warningArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        warningArea.setBackground(Color.WHITE);
        warningArea.setForeground(Color.BLACK);

        JScrollPane scrollPane = new JScrollPane(warningArea);
        scrollPane.setPreferredSize(new Dimension(800, 150)); // Set preferred size

        // Clear previous components and add the scroll pane
        panel_for_stocks_warnings_etc.removeAll();
        panel_for_stocks_warnings_etc.setLayout(new BorderLayout()); // Set layout manager
        panel_for_stocks_warnings_etc.add(scrollPane, BorderLayout.CENTER); // Add scroll pane to the center
        panel_for_stocks_warnings_etc.revalidate();
        panel_for_stocks_warnings_etc.repaint();
    }

    private void edit_inventActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_inventActionPerformed
        int selectedRow = inventory_table.getSelectedRow();  // Get the index of the selected row

        if (selectedRow != -1) {  // If a row is selected
            // Get current values from the selected row
            String sku = inventory_table.getValueAt(selectedRow, 2).toString(); // Assuming SKU is in the third column
            String name = inventory_table.getValueAt(selectedRow, 1).toString(); // Assuming Name is in the second column
            String description = inventory_table.getValueAt(selectedRow, 3).toString(); // Assuming Description is in the fourth column
            String product = inventory_table.getValueAt(selectedRow, 4).toString(); // Assuming Product is in the fifth column
            String quantity = inventory_table.getValueAt(selectedRow, 5).toString(); // Assuming Quantity is in the sixth column

            // Open dialogs to edit values
            String newSku = JOptionPane.showInputDialog(this, "Edit SKU", sku);
            String newName = JOptionPane.showInputDialog(this, "Edit Name", name);
            String newDescription = JOptionPane.showInputDialog(this, "Edit Description", description);
            String newProduct = JOptionPane.showInputDialog(this, "Edit Product", product);
            String newQuantity = JOptionPane.showInputDialog(this, "Edit Quantity", quantity);

            if (newSku != null && newName != null && newDescription != null && newProduct != null && newQuantity != null) {
                // Validate quantity
                int parsedQuantity;
                try {
                    parsedQuantity = Integer.parseInt(newQuantity);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Quantity must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Update the table with the new values
                inventory_table.setValueAt(newSku, selectedRow, 2);
                inventory_table.setValueAt(newName, selectedRow, 1);
                inventory_table.setValueAt(newDescription, selectedRow, 3);
                inventory_table.setValueAt(newProduct, selectedRow, 4);
                inventory_table.setValueAt(parsedQuantity, selectedRow, 5);

                // Update the database with the new values
                try (Connection conn = connectToDatabase()) {
                    String query = "UPDATE inventory SET name = ?, description = ?, product = ?, quantity = ?, sku = ? WHERE sku = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setString(1, newName);
                    stmt.setString(2, newDescription);
                    stmt.setString(3, newProduct);
                    stmt.setInt(4, parsedQuantity);
                    stmt.setString(5, newSku);
                    stmt.setString(6, sku);  // Use the original SKU to identify the record

                    int rowsUpdated = stmt.executeUpdate();
                    if (rowsUpdated > 0) {
                        JOptionPane.showMessageDialog(this, "Item updated successfully!");
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to update item in the database.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to edit.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_edit_inventActionPerformed


    private void search_inventory_input_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_inventory_input_fieldActionPerformed
        try (Connection conn = connectToDatabase()) {
            String keyword = search_inventory_input_field.getText().trim();
            String query = "SELECT * FROM inventory WHERE name LIKE ? OR sku LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, "%" + keyword + "%");
            stmt.setString(2, "%" + keyword + "%");

            ResultSet rs = stmt.executeQuery();
            DefaultTableModel model = (DefaultTableModel) inventory_table.getModel();
            model.setRowCount(0); // Clear existing rows

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("item_id"),
                    rs.getString("name"),
                    rs.getString("sku"),
                    rs.getString("description"),
                    rs.getInt("quantity"),
                    rs.getTimestamp("created_at"),
                    rs.getTimestamp("updated_at"),
                    rs.getString("added_by_username"),
                    rs.getDouble("amount"),});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to search inventory: " + e.getMessage());
        }
    }//GEN-LAST:event_search_inventory_input_fieldActionPerformed

    private void export_report_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_export_report_btnActionPerformed
        try (Connection conn = connectToDatabase()) {
            String query = "SELECT * FROM reservations"; // Modify as needed for filtering
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            StringBuilder reportBuilder = new StringBuilder();
            reportBuilder.append("Reservation ID, Item ID, User ID, Quantity, Down Payment, Status, Reserved By\n");

            while (rs.next()) {
                reportBuilder.append(String.format("%d,%d,%d,%d,%.2f,%s,%s\n",
                        rs.getInt("reservation_id"),
                        rs.getInt("item_id"),
                        rs.getInt("user_id"),
                        rs.getInt("reserved_quantity"),
                        rs.getDouble("down_payment"),
                        rs.getString("status"),
                        rs.getString("reserved_by_username")));
            }

            // Write to CSV file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("reservations_report.csv"))) {
                writer.write(reportBuilder.toString());
                JOptionPane.showMessageDialog(this, "Report exported successfully!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to export report: " + e.getMessage());
        }        // TODO add your handling code here:
    }//GEN-LAST:event_export_report_btnActionPerformed

    private void monthly_top_product_combo_boxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monthly_top_product_combo_boxActionPerformed
        // Get the selected month from the JComboBox
        String selectedMonth = (String) monthly_top_product_combo_box.getSelectedItem();

        // Call the method to create the bar chart with the selected month
        createBarChart(selectedMonth);        // TODO add your handling code here:
    }//GEN-LAST:event_monthly_top_product_combo_boxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane Inventory_Tab;
    private javax.swing.JButton change_role_btn;
    private javax.swing.JPanel chart_panel;
    private javax.swing.JButton dashboard_btn;
    private javax.swing.JButton delete_invent;
    private javax.swing.JButton edit_invent;
    private javax.swing.JButton export_report_btn;
    private javax.swing.JButton inventory_btn;
    private javax.swing.JTable inventory_table;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JComboBox<String> monthly_top_product_combo_box;
    private javax.swing.JPanel panel_for_stocks_warnings_etc;
    private javax.swing.JLabel pending_approvals;
    private javax.swing.JButton report_button;
    private javax.swing.JButton reservation_btn;
    private javax.swing.JLabel reserved_items;
    private javax.swing.JTable reserved_table;
    private javax.swing.JTextField search_inventory_input_field;
    private javax.swing.JTextField search_reservation_input_field;
    private javax.swing.JTextField search_user_input_field;
    private javax.swing.JLabel total_items;
    private javax.swing.JLabel total_user;
    private javax.swing.JButton user_btn1;
    private javax.swing.JTabbedPane user_tab;
    private javax.swing.JTable user_table;
    // End of variables declaration//GEN-END:variables
}
