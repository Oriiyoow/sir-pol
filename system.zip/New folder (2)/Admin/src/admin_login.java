
import javax.swing.JOptionPane;


public class admin_login extends javax.swing.JFrame {


    public admin_login() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        right = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        user_text = new javax.swing.JTextField();
        pass_text = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LOGIN");
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setForeground(new java.awt.Color(204, 255, 255));
        jPanel1.setLayout(null);

        right.setBackground(new java.awt.Color(255, 255, 255));
        right.setLayout(null);

        jPanel3.setBackground(new java.awt.Color(181, 0, 0));
        jPanel3.setLayout(null);

        jLabel4.setBackground(new java.awt.Color(174, 0, 0));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/evsu_main_logo_2.png"))); // NOI18N
        jPanel3.add(jLabel4);
        jLabel4.setBounds(50, 60, 310, 190);

        right.add(jPanel3);
        jPanel3.setBounds(0, 0, 410, 460);

        jPanel1.add(right);
        right.setBounds(0, 0, 410, 460);

        jPanel2.setBackground(new java.awt.Color(247, 242, 242));
        jPanel2.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        jLabel1.setText("ADMIN");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(140, 60, 110, 42);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel2.setText("USERNAME");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(80, 140, 85, 18);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel3.setText("PASSWORD");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(80, 210, 68, 18);

        user_text.setBackground(new java.awt.Color(247, 242, 242));
        user_text.setBorder(null);
        user_text.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_textActionPerformed(evt);
            }
        });
        jPanel2.add(user_text);
        user_text.setBounds(80, 160, 240, 40);

        pass_text.setBackground(new java.awt.Color(247, 242, 242));
        pass_text.setBorder(null);
        jPanel2.add(pass_text);
        pass_text.setBounds(79, 231, 240, 40);

        jButton1.setBackground(new java.awt.Color(181, 0, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("LOGIN");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(110, 310, 160, 40);
        jPanel2.add(jSeparator1);
        jSeparator1.setBounds(80, 200, 240, 10);
        jPanel2.add(jSeparator2);
        jSeparator2.setBounds(80, 270, 240, 20);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-password-30.png"))); // NOI18N
        jPanel2.add(jLabel5);
        jLabel5.setBounds(30, 230, 40, 40);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-user-32.png"))); // NOI18N
        jPanel2.add(jLabel6);
        jLabel6.setBounds(30, 160, 40, 50);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(410, 0, 380, 460);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 800, 460);

        setSize(new java.awt.Dimension(805, 466));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void user_textActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_textActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_user_textActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    String username = user_text.getText();
    String password = new String(pass_text.getPassword());
    
    // Check if credentials match
    if (username.equals("admin") && password.equals("admin")) {
        // Successful login
        Admin num = new Admin();
        num.setVisible(true);
        this.dispose();
    } else {
        // Failed login
        JOptionPane.showMessageDialog(this,
            "Invalid Username or Password!",
            "Login Failed",
            JOptionPane.ERROR_MESSAGE);
        
        // Clear the password field
        pass_text.setText("");
    }        
   
    }//GEN-LAST:event_jButton1ActionPerformed

  
   public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin_login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JPasswordField pass_text;
    private javax.swing.JPanel right;
    private javax.swing.JTextField user_text;
    // End of variables declaration//GEN-END:variables

}